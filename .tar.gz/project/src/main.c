#include "utils.h"
#include "dist_matrix.h"
#include "caps.h"

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include <mpi.h>

void usage(char *exec_name) {
  int rank;
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  
  if (rank == ROOT) {
    printf("Usage: %s s <s> m_scale <m_scale> n_scale <n_scale>\n\n", exec_name);
    printf("       s - number of times matrix can be folded\n         s >= log_7(# Processors)\n\n");
    printf("       scale - scaling of blocks in m, n\n");
  }

  exit(1);
}

void finalize(){
  MPI_Finalize();
}


double fa(int i, int j) {
  //return i + j * 7;
  //return rand() / (1.0 * RAND_MAX);
  //return 1.0;
  //return i + j * 14;
  //return i + (j * 100);
  //return 0.0;
  return (i==0 && j==0) ? 1.0 : 0.0;
  //return (i==j) ? 1.0 : 0.0;
  //return (i % 21 / 3) + (j % 21 / 3) * 7 + j / 21 + (i / 21) * 42;
  //return (i % 14 / 2) + (j % 14 / 2) *7;
  //return (i % 7) + (j %7) *7;
  //return (i <= j) ? 2.0 : 1.0;
}

double fc(int i, int j) {
  return i * j * 0.0;
}

int main(int argc, char *argv[]) {

  int size, rank;
  
  MPI_Init(&argc, &argv);
  atexit(finalize);
  
  MPI_Comm_size(MPI_COMM_WORLD, &size);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);

  int s, k, scale;
  if ( argc != 3 )
    usage(argv[0]);

  s = atoi(argv[1]);
  scale = atoi(argv[2]);

  // Check Parameters
  if ( (k = ilog7(size)) == -1 )
    exitWithError("For this implementation of CAPS we require # Processors to be 7^k");

  if ( s < k )
    exitWithError("Due to the folding it is required s >= k + l");
  
  double max_local_memory_mb = 6 * 1024 / (1.0 * size);
  
  int n;
  int bm, bn;
  int p, q;
    
  if (k % 2 == 0) {
    n = scale * ipow(2, s) * ipow(7, (k/2));
    bm = bn = scale;
    p = q = ipow(7, (k/2));
  } else {
    n = scale * ipow(2, s) * ipow(7, (k+1)/2);
    bm = scale; bn = scale*7;
    p = ipow(7, (k+1)/2); q = ipow(7, (k-1)/2);
  }
  
  // Print Matrix Properties
  if (rank == ROOT) {
    printf("Parameters: {s: %d, k: %d, scale: %d}\n", s, k, scale);
    printf("Local Memory per Processor: %2.2f MBytes\n", max_local_memory_mb);
    printf("Global Dimension: %d x %d\n", n, n);
    printf("Block Dimension: %d x %d\n", bm, bn);
    printf("Processor Dimension: %d x %d\n", p, q);
    printf("Group (P * B) size: %d x %d [Notice always square]\n\n", bm*p, bn*q);
  }

  srand (time(NULL) * rank);
  
  struct dbcl_t a, b, c;
  
  MPI_Comm comm;
  MPI_Comm_dup(MPI_COMM_WORLD, &comm);

  dist_matrix_init(comm, &a, p, q, bm, bn, n, n, fa);
  dist_matrix_init(comm, &b, p, q, bm, bn, n, n, fa);
  dist_matrix_init(comm, &c, p, q, bm, bn, n, n, fc);
  //dist_matrix_print(&a);
  //dist_matrix_print(&b);

  caps(&a, &b, &c, max_local_memory_mb);

  //dist_matrix_print(&c);
  
  dist_matrix_free(&a);
  dist_matrix_free(&b);
  dist_matrix_free(&c);
  return 0;
}
