#ifndef CAPS_H
#define CAPS_H

int caps(struct dbcl_t *a, struct dbcl_t *b, struct dbcl_t *c, double local_memory_avail_mb);

#endif
