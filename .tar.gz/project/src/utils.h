#ifndef UTILS_H
#define UTILS_H

#define ROOT 0

void exitWithError(char *m);

int ilog7(int value);
int ipow(int base, int exp);

#endif
